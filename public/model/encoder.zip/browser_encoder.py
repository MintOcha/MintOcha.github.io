import json, logging, pickle
from typing import Any
import numpy as np
from poke_env.battle import Battle
from bot.encode import encode_battle, IDX, TEAM
logger = logging.getLogger("browser-critic")
MAX_MESSAGES_PER_POSITION = 50000
MESSAGES_TO_IGNORE = set(['', '-anim', '-block', '-burst', '-center', '-combine', '-crit', '-fail', '-fieldactivate', '-hint', '-hitcount', '-miss', '-notarget', '-nothing', '-ohko', '-resisted', '-supereffective', '-waiting', '-zbroken', 'J', 'L', 'askreg', 'badge', 'c', 'chat', 'crit', 'debug', 'deinit', 'expire', 'gametype', 'hidelines', 'html', 'immune', 'inactiveoff', 'init', 'j', 'join', 'l', 'leave', 'n', 'name', 'rated', 'resisted', 'sentchoice', 'split', 'supereffective', 't:', 'teampreview', 'tempnotify', 'tempnotifyoff', 'uhtml', 'uhtmlchange', 'upkeep', 'zbroken'])
def validate_native_request(request: Any, perspective: str) -> None:
    """Strictly validate native Showdown activeRequest without altering state."""
    if not isinstance(request, dict):
        raise ValueError('Request must be an object')
    side = request.get('side')
    if not isinstance(side, dict):
        raise ValueError("Request missing 'side' object")
    if side.get('id') != perspective:
        raise ValueError(f"Request side id '{side.get('id')}' does not match position perspective '{perspective}'")
    if not isinstance(side.get('name'), str) or not side['name']:
        raise ValueError("Request side missing valid 'name' string")
    pokemon_list = side.get('pokemon')
    if not isinstance(pokemon_list, list) or len(pokemon_list) == 0:
        raise ValueError("Request side missing non-empty 'pokemon' list")
    expected_prefix = f'{perspective}: '
    for idx, p in enumerate(pokemon_list):
        if not isinstance(p, dict):
            raise ValueError(f'side.pokemon[{idx}] must be an object')
        ident = p.get('ident')
        if not isinstance(ident, str) or not ident.startswith(expected_prefix):
            raise ValueError(f"side.pokemon[{idx}] invalid ident '{ident}'; expected prefix '{expected_prefix}'")
        if not isinstance(p.get('details'), str) or not p['details']:
            raise ValueError(f"side.pokemon[{idx}] missing 'details' string")
        if not isinstance(p.get('condition'), str) or not p['condition']:
            raise ValueError(f"side.pokemon[{idx}] missing 'condition' string")
        if not isinstance(p.get('moves'), list):
            raise ValueError(f"side.pokemon[{idx}] missing 'moves' list")
        if not isinstance(p.get('active'), bool):
            raise ValueError(f"side.pokemon[{idx}] missing boolean 'active'")

def observation(messages, request, perspective, position_id, prefixes=None):
    if not isinstance(messages, list) or len(messages) > MAX_MESSAGES_PER_POSITION:
        raise ValueError('Invalid protocol message array')
    validate_native_request(request, perspective)
    prefix = (prefixes or {}).get((perspective, request['side']['name']))
    if prefix:
        length, packed = prefix
        battle = pickle.loads(packed)
    else:
        length = 0
        battle = Battle(position_id, request['side']['name'], logger, gen=9)
        battle._player_role = perspective
    for line in messages[length:]:
        if not isinstance(line, str):
            raise ValueError('Protocol messages must be strings')
        parts = line.strip().split('|')
        if not line.startswith('|'):
            parts.insert(0, '')
        if len(parts) < 2 or parts[1] in MESSAGES_TO_IGNORE or parts[1] in ('error', 'bigerror'):
            continue
        battle.parse_message(parts)
    battle.parse_request(request)
    return encode_battle(battle)

def observation_prefixes(positions):
    groups = {}
    for pos in positions:
        if not isinstance(pos, dict):
            continue
        records = [(pos.get('perspective', 'p1'), pos)]
        oracle = pos.get('oracle')
        if isinstance(oracle, list) and len(oracle) == 2:
            records = [(f'p{s + 1}', p) for s, p in enumerate(oracle)]
        for perspective, record in records:
            if not isinstance(record, dict):
                continue
            messages, request = (record.get('messages'), record.get('request'))
            if not isinstance(messages, list) or not isinstance(request, dict):
                continue
            validate_native_request(request, perspective)
            if len(messages) > MAX_MESSAGES_PER_POSITION or any((not isinstance(line, str) for line in messages)):
                raise ValueError('Invalid protocol message array')
            groups.setdefault((perspective, request['side']['name']), []).append(messages)
    prefixes = {}
    for (perspective, name), histories in groups.items():
        if len(histories) < 2:
            continue
        length = 0
        for lines in zip(*histories):
            if any((line != lines[0] for line in lines[1:])):
                break
            length += 1
        if not length:
            continue
        battle = Battle('prefix', name, logger, gen=9)
        battle._player_role = perspective
        for line in histories[0][:length]:
            parts = line.strip().split('|')
            if not line.startswith('|'):
                parts.insert(0, '')
            if len(parts) >= 2 and parts[1] not in MESSAGES_TO_IGNORE and (parts[1] not in ('error', 'bigerror')):
                battle.parse_message(parts)
        prefixes[perspective, name] = (length, pickle.dumps(battle, protocol=pickle.HIGHEST_PROTOCOL))
    return prefixes
def encode_positions(payload):
    positions = json.loads(payload)
    prefixes = observation_prefixes(positions)
    encoded = []
    for pos in positions:
        perspective = pos['perspective']
        oracle = pos.get('oracle')
        if oracle is not None:
            own = 0 if perspective == 'p1' else 1
            full = [observation(p['messages'], p['request'], f'p{s + 1}', pos['id'], prefixes) for s, p in enumerate(oracle)]
            obs = full[own].copy()
            obs[1 + TEAM:] = full[1 - own][1:1 + TEAM]
            obs[1 + TEAM:, IDX['tok_type'][0]] = 2
        else:
            obs = observation(pos['messages'], pos['request'], perspective, pos['id'], prefixes)
        encoded.append(obs)
    return np.stack(encoded).astype(np.float32).ravel()
