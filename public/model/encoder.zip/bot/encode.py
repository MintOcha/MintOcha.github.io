"""Battle -> token tensor.

The battle is encoded as a sequence of entity tokens rather than one flat vector, so
the transformer can attend between specific Pokemon, and between a Pokemon and its
item / tera / ability. Unknown opponent attributes get a dedicated <unk> index, which
is what the belief head learns to fill in.

Layout (SEQ_LEN tokens):
    0            field token   (weather, terrain, hazards, turn)
    1  .. 6      our team      (slot order, active flagged)
    7  .. 12     opponent team (revealed or <unk> placeholder)

Every token is the same width; a leading type-id tells the model what kind of token it
is. Per-token feature block:

    [tok_type, species, item, ability, tera, status, role,
     move0..move3, hp_frac, atk..eva boosts(7), active, fainted,
     revealed, is_ours, level, n_types, type0, type1]

Categorical fields are emitted as integer ids (embedded downstream); continuous ones
are already normalised to roughly [0, 1].
"""
import numpy as np

from bot.vocab import DEX, BOOSTS, EFFECTS, FIELDS, SIDE_CONDITIONS, norm

TEAM = 6
SEQ_LEN = 1 + TEAM + TEAM          # field + own + opponent
BELIEF_SLOTS = TEAM
OBSERVATION_CONTRACT = "native-frames-v2"
STATS = ("atk", "def", "spa", "spd", "spe")
STAT_SCALE = 1000.0

# --- per-token feature offsets -------------------------------------------------
IDX = {}


def _mk_layout():
    off = 0
    def add(name, width=1):
        nonlocal off
        IDX[name] = (off, off + width)
        off += width
    add("tok_type")
    add("species"); add("item"); add("ability"); add("tera"); add("status"); add("role")
    add("moves", 4)
    add("hp")
    add("boosts", len(BOOSTS))
    add("active"); add("fainted"); add("revealed"); add("is_ours"); add("level")
    # Facts defined by what already happened. poke-env tracks each of these on the
    # Pokemon, so they cost one scalar rather than a stacked history frame:
    # last_move identifies a Choice lock, terastallized marks a spent once-per-battle
    # resource, and recharge/prepare/first_turn constrain what may be chosen next.
    add("last_move"); add("terastallized"); add("must_recharge")
    add("preparing"); add("first_turn"); add("active_turns")
    add("effects", len(EFFECTS))
    add("types", 2)
    # field-token payload (only meaningful on token 0)
    add("weather"); add("weather_age")
    add("field_flags", len(FIELDS))
    add("field_ages", len(FIELDS))
    add("our_hazards", len(SIDE_CONDITIONS))
    add("opp_hazards", len(SIDE_CONDITIONS))
    add("turn")
    add("our_alive"); add("opp_alive")
    add("can_tera"); add("opp_used_tera"); add("force_switch"); add("trapped")
    add("stats", len(STATS)); add("stats_known", len(STATS))
    add("hp_exact"); add("max_hp")
    add("move_pp", 4); add("move_pp_known", 4); add("move_disabled", 4)
    return off


TOK_DIM = _mk_layout()

# categorical feature names -> vocab size, used by the model to build embeddings
CATEGORICAL = {
    "tok_type": 3,
    "species": len(DEX.species),
    "item": len(DEX.items),
    "ability": len(DEX.abilities),
    "tera": len(DEX.types),
    "status": len(DEX.status),
    "role": len(DEX.roles),
    "moves": len(DEX.moves),
    "last_move": len(DEX.moves),
    "weather": len(DEX.weather),
    "types": len(DEX.types),
}


def validate_observation_contract(metadata):
    if metadata.get("observation_contract") != OBSERVATION_CONTRACT:
        raise ValueError("Incompatible observation contract; rebuild data or retrain the checkpoint")

# Action space: 4 moves, 4 moves+tera, 6 switches
N_MOVES = 4
N_ACTIONS = N_MOVES * 2 + TEAM


def _set(tok, name, value):
    a, b = IDX[name]
    if b - a == 1:
        tok[a] = value
    else:
        tok[a:b] = value


def _mon_token(mon, ours, active, revealed, slot_moves=None, truth=None):
    """Encode one Pokemon, using exact own-team data when available."""
    t = np.zeros(TOK_DIM, dtype=np.float32)
    _set(t, "tok_type", 1 if ours else 2)
    if mon is None and truth is None:
        _set(t, "is_ours", 1.0 if ours else 0.0)
        return t

    truth = truth or {}
    _set(t, "is_ours", float(ours))
    _set(t, "active", float(active))
    _set(t, "revealed", float(revealed))
    _set(t, "fainted", float(getattr(mon, "fainted", False)))
    boosts = getattr(mon, "boosts", {})
    _set(t, "boosts", [boosts.get(stat, 0) / 6.0 for stat in BOOSTS])
    species = truth.get("species") or getattr(mon, "species", None) \
        or getattr(mon, "base_species", None)
    _set(t, "species", DEX.species.get(species))
    _set(t, "item", DEX.items.get(truth.get("item") or getattr(mon, "item", None)))
    _set(t, "ability", DEX.abilities.get(
        truth.get("ability") or getattr(mon, "ability", None)))

    tera = truth.get("teraType") or getattr(mon, "tera_type", None)
    tera_name = getattr(tera, "name", tera)
    _set(t, "tera", DEX.types.get(tera_name))

    role = truth.get("role")
    if not role and ours:
        known_moves = truth.get("moves") or getattr(mon, "moves", {}).keys()
        candidates = DEX.candidates(species, known_moves,
                                    truth.get("item") or getattr(mon, "item", None),
                                    truth.get("ability") or getattr(mon, "ability", None),
                                    tera_name)
        if len(candidates) == 1:
            role = candidates[0].role
    _set(t, "role", DEX.roles.get(role))

    status = getattr(mon, "status", None)
    _set(t, "status", DEX.status.get(getattr(status, "name", status)))

    moves = list(slot_moves) if slot_moves is not None else list(
        truth.get("moves") or getattr(mon, "moves", {}).keys())
    mv = np.zeros(4, dtype=np.float32)
    pp_arr = np.zeros(4, dtype=np.float32)
    pp_known = np.zeros(4, dtype=np.float32)
    dis_arr = np.zeros(4, dtype=np.float32)

    mon_moves_dict = getattr(mon, "moves", {}) if isinstance(getattr(mon, "moves", {}), dict) else {}
    for i, move in enumerate(moves[:4]):
        mv[i] = DEX.moves.get(move)
        m_obj = mon_moves_dict.get(move)
        if ours and m_obj is not None:
            pp_arr[i] = float(m_obj.current_pp) / (m_obj.max_pp or 1)
            pp_known[i] = 1.0
    _set(t, "moves", mv)

    _set(t, "move_pp", pp_arr)
    _set(t, "move_pp_known", pp_known)
    _set(t, "move_disabled", dis_arr)

    try:
        hp = float(getattr(mon, "current_hp_fraction", 0.0) or 0.0)
    except Exception:
        hp = 0.0
    _set(t, "hp", np.clip(hp, 0.0, 1.0))

    if ours and mon is not None:
        stats = mon.stats
        _set(t, "stats", [(stats.get(stat) or 0) / STAT_SCALE for stat in STATS])
        _set(t, "stats_known", [float(stats.get(stat) is not None) for stat in STATS])
        _set(t, "hp_exact", float(mon.current_hp or 0) / STAT_SCALE)
        _set(t, "max_hp", float(mon.max_hp or 0) / STAT_SCALE)
    level = truth.get("level") or getattr(mon, "level", 80) or 80
    _set(t, "level", float(level) / 100.0)
    last = getattr(mon, "last_move", None)
    _set(t, "last_move", DEX.moves.get(norm(last.id)) if last is not None else 0)
    _set(t, "terastallized",
         1.0 if getattr(mon, "is_terastallized", False) else 0.0)
    _set(t, "must_recharge", 1.0 if getattr(mon, "must_recharge", False) else 0.0)
    _set(t, "preparing", 1.0 if getattr(mon, "preparing", False) else 0.0)
    _set(t, "first_turn", 1.0 if getattr(mon, "first_turn", False) else 0.0)
    _set(t, "active_turns",
         min(float(getattr(mon, "active_turns", 0) or 0) / 10.0, 1.0))

    # Volatile effects are what a player reads off the screen: a Substitute or an
    # Encore changes which action is correct without changing any other field.
    present = {norm(getattr(e, "name", e)) for e in (getattr(mon, "effects", None) or {})}
    _set(t, "effects", np.array([1.0 if e in present else 0.0 for e in EFFECTS],
                                dtype=np.float32))

    types = [ty for ty in (getattr(mon, "types", None) or []) if ty is not None]
    tv = np.zeros(2, dtype=np.float32)
    for i, ty in enumerate(types[:2]):
        tv[i] = DEX.types.get(getattr(ty, "name", ty))
    _set(t, "types", tv)
    return t


def _field_token(battle):
    t = np.zeros(TOK_DIM, dtype=np.float32)
    _set(t, "tok_type", 0)
    turn = float(battle.turn or 0)

    # poke-env maps each active condition to the turn it started, so elapsed time is
    # exact rather than inferred: Trick Room with two turns left is a different
    # position from Trick Room with five, and the flag alone cannot express that.
    def age(started):
        return min(max(turn - float(started), 0.0) / 8.0, 1.0)

    weather = battle.weather or {}
    wname = None
    weather_age = 0.0
    if weather:
        w, started = next(iter(weather.items()))
        wname = getattr(w, "name", w)
        weather_age = age(started)
    _set(t, "weather", DEX.weather.get(wname))
    _set(t, "weather_age", weather_age)

    fields = {norm(getattr(f, "name", f)): s for f, s in (battle.fields or {}).items()}
    _set(t, "field_flags", np.array([1.0 if f in fields else 0.0 for f in FIELDS],
                                    dtype=np.float32))
    _set(t, "field_ages", np.array([age(fields[f]) if f in fields else 0.0
                                    for f in FIELDS], dtype=np.float32))

    def hz(conds):
        got = {norm(getattr(c, "name", c)): v for c, v in (conds or {}).items()}
        # Stackable conditions store a layer count, the rest store a start turn; both
        # are the quantity that matters, normalised to a comparable scale.
        return np.array([min(float(got[s]) / 3.0, 1.0) if s in got else 0.0
                         for s in SIDE_CONDITIONS], dtype=np.float32)

    _set(t, "our_hazards", hz(battle.side_conditions))
    _set(t, "opp_hazards", hz(battle.opponent_side_conditions))
    _set(t, "turn", min(turn / 50.0, 2.0))

    team = list((battle.team or {}).values())
    opp = list((battle.opponent_team or {}).values())
    _set(t, "our_alive", sum(1 for m in team if not m.fainted) / 6.0)
    _set(t, "opp_alive", (6 - sum(1 for m in opp if m.fainted)) / 6.0)
    _set(t, "can_tera", 1.0 if getattr(battle, "can_tera", None) else 0.0)
    _set(t, "opp_used_tera",
         1.0 if getattr(battle, "opponent_used_tera", False) else 0.0)
    _set(t, "force_switch", 1.0 if battle.force_switch else 0.0)
    _set(t, "trapped", 1.0 if getattr(battle, "trapped", False) else 0.0)
    return t


def ordered_team(battle, own_truth=None):
    """Our six Pokemon in a stable slot order.

    Stable ordering matters: switch actions are indexed by team slot, so the same
    Pokemon must occupy the same token position every turn of the battle.
    """
    team = list((battle.team or {}).values())
    if own_truth:
        order, used = [], set()
        by_species = {}
        for m in team:
            by_species.setdefault(norm(getattr(m, "base_species", m.species)), []).append(m)
        for p in own_truth[:TEAM]:
            key = norm(p.get("species"))
            cands = by_species.get(key)
            if not cands:
                for k, v in by_species.items():
                    if v and (k.startswith(key) or key.startswith(k)):
                        cands = v
                        break
            if cands:
                m = cands.pop(0)
                order.append(m)
                used.add(id(m))
            else:
                order.append(None)
        for m in team:
            if id(m) not in used and None in order:
                order[order.index(None)] = m
        return order[:TEAM] + [None] * max(0, TEAM - len(order))
    # Dict insertion order is stable; native switch indices instead follow the
    # current request order and must be resolved by Pokémon identity.
    return (team + [None] * TEAM)[:TEAM]


def ordered_opponent(battle):
    """Opponent Pokemon in reveal order, then empty slots.

    Reveal order (not alphabetical) is the only ordering available at inference time
    that is also stable within a battle, so belief labels can be aligned to it.
    poke-env's `opponent_team` dict is already insertion-ordered by first sighting.
    """
    opp = list((battle.opponent_team or {}).values())
    return (opp + [None] * TEAM)[:TEAM]




def encode_battle(battle, own_truth=None):
    """Full observation tensor: (SEQ_LEN, TOK_DIM)."""
    toks = np.zeros((SEQ_LEN, TOK_DIM), dtype=np.float32)
    toks[0] = _field_token(battle)
    own_team = ordered_team(battle, own_truth)
    active = battle.active_pokemon
    request = battle.last_request or {}
    for i, mon in enumerate(own_team):
        truth = own_truth[i] if own_truth and i < len(own_truth) else None
        toks[1 + i] = _mon_token(mon, ours=True,
                                 active=(mon is not None and mon is active),
                                 revealed=True, truth=truth,
                                 slot_moves=active_move_slots(battle, mon) if mon is active else None)
        if mon is active and request.get("active"):
            for slot, move in enumerate(request["active"][0]["moves"][:N_MOVES]):
                if "pp" in move and "maxpp" in move:
                    toks[1 + i, IDX["move_pp"][0] + slot] = move["pp"] / (move["maxpp"] or 1)
                    toks[1 + i, IDX["move_pp_known"][0] + slot] = 1.0
                toks[1 + i, IDX["move_disabled"][0] + slot] = float(move.get("disabled", False))

    opp_active = battle.opponent_active_pokemon
    for i, mon in enumerate(ordered_opponent(battle)):
        is_active = mon is not None and mon is opp_active
        tok = _mon_token(mon, ours=False, active=is_active,
                         revealed=mon is not None)
        toks[1 + TEAM + i] = tok
    return toks


def legal_action_mask_from_observation(obs):
    """Legal-action mask recoverable from one encoded first-person state."""
    mask = np.zeros(N_ACTIONS, dtype=bool)
    active_rows = np.flatnonzero(obs[1:1 + TEAM, IDX["active"][0]] > 0.5)
    force_switch = obs[0, IDX["force_switch"][0]] > 0.5
    if len(active_rows) and not force_switch:
        moves = obs[1 + active_rows[0], IDX["moves"][0]:IDX["moves"][1]] > 0
        mask[:N_MOVES] = moves
        if obs[0, IDX["can_tera"][0]] > 0.5:
            mask[N_MOVES:N_MOVES * 2] = moves

    own = obs[1:1 + TEAM]
    present = own[:, IDX["is_ours"][0]] > 0.5
    alive = own[:, IDX["fainted"][0]] < 0.5
    inactive = own[:, IDX["active"][0]] < 0.5
    mask[N_MOVES * 2:] = present & alive & inactive
    return mask


def legal_action_mask(battle):
    """Boolean mask over the N_ACTIONS action space for the current request."""
    mask = np.zeros(N_ACTIONS, dtype=bool)
    if battle.force_switch:
        for i, mon in enumerate(ordered_team(battle, getattr(battle, "_own_truth", None))):
            if mon is not None and mon in (battle.available_switches or []):
                mask[N_MOVES * 2 + i] = True
        return mask

    avail = list(battle.available_moves or [])
    active = battle.active_pokemon
    slots = active_move_slots(battle, active)
    for i, mv in enumerate(slots):
        if mv is not None and any(norm(mv) == norm(a.id) for a in avail):
            mask[i] = True
            if getattr(battle, "can_tera", None):
                mask[N_MOVES + i] = True

    for i, mon in enumerate(ordered_team(battle, getattr(battle, "_own_truth", None))):
        if mon is not None and mon in (battle.available_switches or []):
            mask[N_MOVES * 2 + i] = True

    return mask


def active_move_slots(battle, active):
    """Move ids in a stable slot order for the active Pokemon."""
    if active is None:
        return [None] * N_MOVES
    request = battle.last_request if hasattr(battle, "last_request") else getattr(battle, "_last_request", {})
    if active is battle.active_pokemon and request and request.get("active"):
        moves = [norm(move["id"]) for move in request["active"][0]["moves"]]
        return (moves + [None] * N_MOVES)[:N_MOVES]
    truth = getattr(battle, "_own_truth", None)
    if truth:
        key = norm(getattr(active, "base_species", active.species))
        for p in truth:
            pk = norm(p.get("species"))
            if pk == key or pk.startswith(key) or key.startswith(pk):
                mv = [norm(m) for m in p.get("moves", [])]
                return (mv + [None] * N_MOVES)[:N_MOVES]
    # The moves mapping follows Showdown's request order (the four move slots).
    # Sorting here would map policy logits to different live moves than training.
    mv = [norm(m) for m in getattr(active, "moves", {})]
    return (mv + [None] * N_MOVES)[:N_MOVES]


def action_index(battle, action, own_truth, party=None):
    """Map a logged inputlog choice onto our fixed action space.

    `party` is the current Showdown party permutation (indices into the seed team
    order). Switch choices index that permuted array, so they must be translated back
    to the stable team slot the encoder assigns tokens to.
    """
    if action["kind"] == "move":
        battle._own_truth = own_truth
        slots = active_move_slots(battle, battle.active_pokemon)
        for i, mv in enumerate(slots):
            if mv and mv == action["id"]:
                return N_MOVES + i if action["tera"] else i
        return None
    if action["kind"] == "switch":
        i = action["slot"] - 1
        if party is not None:
            if not (0 <= i < len(party)):
                return None
            slot = party[i]
        else:
            slot = i
        if 0 <= slot < TEAM:
            return N_MOVES * 2 + slot
    return None
