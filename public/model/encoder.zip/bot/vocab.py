import json
import os
import re
import unicodedata
from typing import NamedTuple
SIDE_CONDITIONS = ['stealthrock', 'spikes', 'toxicspikes', 'stickyweb', 'reflect', 'lightscreen', 'auroraveil', 'tailwind', 'safeguard', 'mist']
FIELDS = ['trickroom', 'gravity', 'electricterrain', 'grassyterrain', 'mistyterrain', 'psychicterrain', 'magicroom', 'wonderroom']
BOOSTS = ['atk', 'def', 'spa', 'spd', 'spe', 'accuracy', 'evasion']
EFFECTS = ['protect', 'substitute', 'quarkdrive', 'roost', 'protosynthesis', 'confusion', 'healblock', 'encore', 'leechseed', 'charge', 'taunt', 'yawn', 'typechange', 'throatchop', 'slowstart', 'disable', 'futuresight', 'saltcure', 'destinybond', 'perishsong', 'partiallytrapped', 'attract', 'curse', 'ingrain', 'aquaring', 'magnetrise', 'imprison', 'octolock', 'glaiverush', 'flashfire', 'focusenergy', 'laserfocus', 'lockedmove', 'mustrecharge', 'supremeoverlord', 'illusion', 'stockpile', 'powertrick']

def norm(s):
    """Showdown id normalisation: lowercase alphanumerics only."""
    if s is None:
        return ''
    s = unicodedata.normalize('NFKD', str(s))
    return ''.join((c for c in s.lower() if c.isalnum()))

class Vocab:
    """Bidirectional string <-> index map with a reserved 0 = UNKNOWN slot.

    Index 0 always means "not known yet", which is the single most common state for
    opponent information and needs its own embedding rather than being folded into
    some arbitrary real entry.
    """

    def __init__(self, items, name=''):
        self.name = name
        self.itos = ['<unk>'] + sorted(set(items))
        self.stoi = {s: i for i, s in enumerate(self.itos)}

    def __len__(self):
        return len(self.itos)

    def get(self, s):
        return self.stoi.get(norm(s), 0)

    def __repr__(self):
        return f'Vocab({self.name}, n={len(self)})'

class Set(NamedTuple):
    """One concrete Random Battle set, exactly as the server can generate it."""
    moves: tuple
    item: str
    ability: str
    tera: str
    level: int
    role: str
    count: int

class Dex:
    """Random Battle set knowledge: what each species can possibly be.

    This is the prior the belief head refines. `candidates(species)` enumerates the
    concrete sets still consistent with what has been observed, so a single revealed
    move is a proof that eliminates sets rather than a statistical hint.
    """

    def __init__(self):
        self.sets = _load_sets()
        moves, abilities, items, roles = (set(), set(), set(), set())
        for species_sets in self.sets.values():
            for s in species_sets:
                moves.update(s.moves)
                abilities.add(s.ability)
                items.add(s.item)
                roles.add(s.role)
        items.update(_load_item_names())
        items.discard('')
        roles.discard('')
        self.species = Vocab(self.sets, 'species')
        for name, pokemon in GenData.from_gen(9).pokedex.items():
            species_id = self.species.get(name)
            if species_id:
                for cosmetic in pokemon.get('cosmeticFormes', ()):
                    self.species.stoi[norm(cosmetic)] = species_id
        self.moves = Vocab(moves, 'moves')
        self.abilities = Vocab(abilities, 'abilities')
        self.items = Vocab(items, 'items')
        self.roles = Vocab(roles, 'roles')
        self.types = Vocab(TYPES, 'types')
        self.status = Vocab(STATUSES, 'status')
        self.weather = Vocab(WEATHERS, 'weather')

    def entry(self, species):
        return self.sets.get(norm(species), ())

    def level(self, species):
        """Random Battle levels are fixed per species."""
        sets = self.entry(species)
        return sets[0].level if sets else 80

    def move_pool(self, species):
        """Every move the species can carry, across all its sets."""
        return {m for s in self.entry(species) for m in s.moves}

    def candidates(self, species, known_moves=(), known_item=None, known_ability=None, known_tera=None):
        """Sets still consistent with what has been revealed, most frequent first.

        Randbats' whole advantage: this shrinks fast and exactly, because each entry
        is a real four-move set rather than a pool the server draws from.
        """
        known = {norm(m) for m in known_moves if m}
        item, ability, tera = (norm(known_item), norm(known_ability), norm(known_tera))
        return [s for s in self.entry(species) if known <= set(s.moves) and (not item or item == s.item) and (not ability or ability == s.ability) and (not tera or tera == s.tera)]
_data = json.load(open(os.path.join(os.path.dirname(__file__), "vocabulary.json")))
DEX = object.__new__(Dex)
for _name, _table in _data["vocabulary"].items():
    _v = object.__new__(Vocab)
    _v.stoi = _table
    setattr(DEX, _name, _v)
DEX.sets = {k: tuple(Set(*s) for s in v) for k, v in _data["sets"].items()}
for _name in _data["vocabulary"]:
    _v = getattr(DEX, _name)
    _v.itos = [None] * (max(_v.stoi.values()) + 1)
